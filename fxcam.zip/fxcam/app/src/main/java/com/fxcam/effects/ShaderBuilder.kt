package com.fxcam.effects

object ShaderBuilder {

    private const val PI = 3.14159265359f

    fun buildFragmentShader(effects: List<Effect>, time: Float, aspect: Float): String {
        val sb = StringBuilder()
        sb.append("""
#version 300 es
precision highp float;

in vec2 vTexCoord;
uniform sampler2D uTexture;
uniform float uTime;
uniform float uAspect;
out vec4 fragColor;

""")
        sb.append("void main() {\n")
        sb.append("    vec2 uv = vTexCoord;\n")
        sb.append("    vec2 orig = vTexCoord;\n")
        sb.append("    float t = uTime;\n")
        sb.append("    float aspect = uAspect;\n")
        sb.append("    vec3 final_rgb = vec3(-1.0);\n\n")

        for (effect in effects) {
            if (!effect.enabled) continue
            sb.append("    // Effect: ${effect.name}\n")
            sb.append("    {\n")
            when (effect.id) {
                "hue_shift" -> emitHueShift(sb, effect)
                "v_wiggle"  -> emitVWiggle(sb, effect)
                "h_wiggle"  -> emitHWiggle(sb, effect)
                "vwave"     -> emitVWave(sb, effect)
                "hwave"     -> emitHWave(sb, effect)
                "swirl"     -> emitSwirl(sb, effect)
                "fish"      -> emitFisheye(sb, effect)
                "ripple"    -> emitRipple(sb, effect)
                "fractal"   -> emitFractal(sb, effect)
                "rays"      -> emitRays(sb, effect)
                "glow"      -> emitGlow(sb, effect)
                "nb_wiggle" -> emitNbWiggle(sb, effect)
                "crt_beam"  -> emitCrtBeam(sb, effect)
            }
            sb.append("    }\n\n")
        }

        sb.append("""
    if (final_rgb.r < 0.0) final_rgb = texture(uTexture, uv).rgb;
    fragColor = vec4(final_rgb, 1.0);
}
""")
        return sb.toString()
    }

    private fun Effect.p(key: String) = params.find { it.key == key }?.value ?: 0f

    private fun emitHueShift(sb: StringBuilder, e: Effect) {
        val shift = e.p("shift") / 360f
        val sat = e.p("saturation")
        sb.append("""
        vec3 hs_col = (final_rgb.r < 0.0) ? texture(uTexture, uv).rgb : final_rgb;
        // RGB to HSV
        float hs_maxc = max(hs_col.r, max(hs_col.g, hs_col.b));
        float hs_minc = min(hs_col.r, min(hs_col.g, hs_col.b));
        float hs_d = hs_maxc - hs_minc;
        float hs_h = 0.0;
        if (hs_d > 0.0001) {
            if (hs_maxc == hs_col.r) hs_h = mod((hs_col.g - hs_col.b) / hs_d, 6.0);
            else if (hs_maxc == hs_col.g) hs_h = (hs_col.b - hs_col.r) / hs_d + 2.0;
            else hs_h = (hs_col.r - hs_col.g) / hs_d + 4.0;
            hs_h /= 6.0;
        }
        float hs_s = (hs_maxc < 0.0001) ? 0.0 : hs_d / hs_maxc;
        float hs_v = hs_maxc;
        hs_h = mod(hs_h + ${shift}f, 1.0);
        hs_s = clamp(hs_s * ${sat}f, 0.0, 1.0);
        // HSV to RGB
        float hs_c2 = hs_v * hs_s;
        float hs_x = hs_c2 * (1.0 - abs(mod(hs_h * 6.0, 2.0) - 1.0));
        float hs_m = hs_v - hs_c2;
        vec3 hs_rgb;
        int hs_i = int(hs_h * 6.0);
        if      (hs_i == 0) hs_rgb = vec3(hs_c2, hs_x, 0.0);
        else if (hs_i == 1) hs_rgb = vec3(hs_x, hs_c2, 0.0);
        else if (hs_i == 2) hs_rgb = vec3(0.0, hs_c2, hs_x);
        else if (hs_i == 3) hs_rgb = vec3(0.0, hs_x, hs_c2);
        else if (hs_i == 4) hs_rgb = vec3(hs_x, 0.0, hs_c2);
        else                hs_rgb = vec3(hs_c2, 0.0, hs_x);
        final_rgb = hs_rgb + hs_m;
""")
    }

    private fun emitVWiggle(sb: StringBuilder, e: Effect) {
        val se = e.p("se"); val rad = e.p("radius") * 0.01f; val skw = e.p("skew")
        sb.append("""
        float vw_val = ${se}f * 0.1;
        float vw_rad = ${rad}f;
        float vw_skw = ${skw}f;
        uv.y += sin(t * vw_val - orig.x * vw_skw * 3.0)
              * (vw_rad * (1.0 + orig.x * vw_skw * 0.5))
              * sin(orig.y * ${PI}f);
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitHWiggle(sb: StringBuilder, e: Effect) {
        val se = e.p("se"); val rad = e.p("radius") * 0.01f; val skw = e.p("skew")
        sb.append("""
        float hw_val = ${se}f * 0.1;
        float hw_rad = ${rad}f;
        float hw_skw = ${skw}f;
        uv.x += sin(t * hw_val - orig.y * hw_skw * 3.0)
              * (hw_rad * (1.0 + orig.y * hw_skw * 0.5))
              * sin(orig.x * ${PI}f);
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitVWave(sb: StringBuilder, e: Effect) {
        val amp = e.p("se") * 0.01f; val freq = e.p("stretch"); val spd = e.p("speed")
        sb.append("""
        uv.x += sin(orig.y * ${freq}f + t * ${spd}f) * ${amp}f;
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitHWave(sb: StringBuilder, e: Effect) {
        val amp = e.p("se") * 0.01f; val freq = e.p("stretch"); val spd = e.p("speed")
        sb.append("""
        uv.y += sin(orig.x * ${freq}f + t * ${spd}f) * ${amp}f;
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitSwirl(sb: StringBuilder, e: Effect) {
        val rot = e.p("se"); val rad = e.p("radius") * 0.01f
        val cx = e.p("posx"); val cy = e.p("posy")
        sb.append("""
        vec2 sw_ctr = vec2(${cx}f, ${cy}f);
        vec2 sw_st = (uv - sw_ctr) * vec2(aspect, 1.0);
        float sw_th = ${rot}f * exp(-length(sw_st) / (${rad}f * 100.0 + 0.0001)) * ${PI}f / 180.0;
        float sw_c = cos(sw_th), sw_s = sin(sw_th);
        uv = sw_ctr + vec2(sw_st.x*sw_c - sw_st.y*sw_s, sw_st.x*sw_s + sw_st.y*sw_c) / vec2(aspect, 1.0);
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitFisheye(sb: StringBuilder, e: Effect) {
        val str = e.p("se"); val rad = e.p("radius") * 0.01f
        val cx = e.p("posx"); val cy = e.p("posy")
        sb.append("""
        vec2 fe_ctr = vec2(${cx}f, ${cy}f);
        vec2 fe_st = (uv - fe_ctr) * vec2(aspect, 1.0);
        float fe_lens = ${str}f * exp(-dot(fe_st, fe_st) / (${rad}f * ${rad}f * 10000.0 + 0.0001));
        uv = fe_ctr + fe_st * (1.0 - fe_lens) / vec2(aspect, 1.0);
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitRipple(sb: StringBuilder, e: Effect) {
        val freq = e.p("se"); val amp = e.p("radius") * 0.01f
        val spd = e.p("speed"); val cx = e.p("posx"); val cy = e.p("posy")
        sb.append("""
        vec2 rp_ctr = vec2(${cx}f, ${cy}f);
        vec2 rp_st = (uv - rp_ctr) * vec2(aspect, 1.0);
        float rp_d = length(rp_st);
        uv += (rp_st / (rp_d + 0.0001)) * sin(rp_d * ${freq}f - t * ${spd}f) * ${amp}f / vec2(aspect, 1.0);
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitFractal(sb: StringBuilder, e: Effect) {
        val scale = e.p("se"); val rad = e.p("radius") * 0.01f
        val spd = e.p("speed"); val cx = e.p("posx"); val cy = e.p("posy")
        sb.append("""
        vec2 fr_ctr = vec2(${cx}f, ${cy}f);
        vec2 fr_st = (uv - fr_ctr) * vec2(aspect, 1.0);
        vec2 fr_p = uv * ${scale}f;
        for (int j = 1; j < 4; j++) {
            float fj = float(j), fr_phase = fj * 3.0;
            float fr_inv = 0.3 / fj;
            fr_p.x += fr_inv * sin(fr_phase * fr_p.y + t * ${spd}f);
            fr_p.y += fr_inv * sin(fr_phase * fr_p.x + t * ${spd}f);
        }
        uv += (fr_p - uv * ${scale}f) * 0.1 * smoothstep(${rad}f * 100.0, 0.0, length(fr_st));
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitRays(sb: StringBuilder, e: Effect) {
        val len = e.p("length"); val thr = e.p("threshold"); val str = e.p("strength")
        sb.append("""
        vec2 r_d = (uv - vec2(0.5)) * (${len}f / 18.0);
        float r_j = fract(52.9829 * fract(dot(uv * 512.0, vec2(0.06, 0.05))));
        vec2 r_uv = uv + r_d * r_j;
        vec3 r_a = vec3(0.0); float r_tw = 0.0001; float r_f = 1.0;
        for (int j = 0; j < 18; j++) {
            vec3 rs = texture(uTexture, clamp(r_uv, 0.0, 1.0)).rgb;
            float rl = (rs.r + rs.g + rs.b) * 0.333;
            float rw = clamp((rl - ${thr}f) * 5.0, 0.0, 1.0) * r_f;
            r_a += rs * rw; r_tw += rw; r_f *= 0.93; r_uv -= r_d;
        }
        vec3 r_b = (final_rgb.r < 0.0) ? texture(uTexture, uv).rgb : final_rgb;
        final_rgb = mix(r_b, r_a / r_tw, clamp((r_tw / 18.0) * ${str}f * 5.0, 0.0, 1.0));
""")
    }

    private fun emitGlow(sb: StringBuilder, e: Effect) {
        val pct = e.p("percentage"); val intensity = e.p("intensity"); val sup = e.p("suppression")
        sb.append("""
        vec3 gw_src = (final_rgb.r < 0.0) ? texture(uTexture, uv).rgb : final_rgb;
        float gw_acc = 0.0;
        vec2 gw_sz = vec2(${pct}f) / 512.0;
        for (int gx = -3; gx <= 3; gx++) {
            for (int gy = -3; gy <= 3; gy++) {
                vec3 gs = texture(uTexture, clamp(uv + vec2(float(gx), float(gy)) * gw_sz, 0.0, 1.0)).rgb;
                gw_acc += max(dot(gs, vec3(0.299, 0.587, 0.114)) - ${sup}f, 0.0);
            }
        }
        final_rgb = gw_src + vec3(1.0) * gw_acc * (0.02 * ${intensity}f);
""")
    }

    private fun emitNbWiggle(sb: StringBuilder, e: Effect) {
        val freq = e.p("se"); val rate = e.p("rate") * 0.1f
        val str = e.p("strength") * 0.01f; val drift = e.p("drift")
        val crop = e.p("crop") * 0.01f; val mx = e.p("posx"); val my = e.p("posy")
        sb.append("""
        uv = (uv - 0.5) * (1.0 - ${crop}f) + 0.5;
        float nb_phase = t * ${rate}f + ${drift}f;
        float nb_waveX = sin(nb_phase - orig.y * ${freq}f);
        float nb_waveY = sin(nb_phase - orig.x * ${freq}f);
        float nb_edge = sin(orig.x * ${PI}f) * sin(orig.y * ${PI}f);
        uv += vec2(nb_waveX * ${mx}f, nb_waveY * ${my}f) * (${str}f * nb_edge);
        final_rgb = texture(uTexture, clamp(uv, 0.0, 1.0)).rgb;
""")
    }

    private fun emitCrtBeam(sb: StringBuilder, e: Effect) {
        val spd = e.p("speed"); val str = e.p("strength"); val wid = e.p("radius")
        sb.append("""
        float crt_H = 1080.0;
        float crt_bY = uv.y * crt_H;
        float crt_beamY = mod(crt_bY - t * ${spd}f * 60.0 + crt_H, crt_H) - crt_H / 2.0;
        float crt_beam = ${str}f * exp(-${wid}f * crt_beamY * crt_beamY);
        vec3 crt_src = (final_rgb.r < 0.0) ? texture(uTexture, uv).rgb : final_rgb;
        final_rgb = clamp(crt_src + vec3(crt_beam), 0.0, 1.0);
""")
    }

    val VERTEX_SHADER = """
#version 300 es
in vec4 aPosition;
in vec2 aTexCoord;
out vec2 vTexCoord;
void main() {
    gl_Position = aPosition;
    vTexCoord = aTexCoord;
}
""".trimIndent()

    val CUSTOM_SHADER_TEMPLATE = """
#version 300 es
precision highp float;

in vec2 vTexCoord;
uniform sampler2D uTexture;
uniform float uTime;
uniform float uAspect;
out vec4 fragColor;

void main() {
    vec2 uv = vTexCoord;
    float t = uTime;
    
    // Sample the original image
    vec4 color = texture(uTexture, uv);
    
    // --- Your effect here ---
    // Example: simple hue rotation
    color.r = sin(uv.x * 10.0 + t) * 0.5 + 0.5;
    
    fragColor = color;
}
""".trimIndent()
}
