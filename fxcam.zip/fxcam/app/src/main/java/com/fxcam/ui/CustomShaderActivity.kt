package com.fxcam.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.opengl.GLSurfaceView
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.fxcam.R
import com.fxcam.effects.ShaderBuilder
import com.fxcam.vulkan.EffectRenderer

class CustomShaderActivity : AppCompatActivity() {

    private lateinit var glSurface: GLSurfaceView
    private lateinit var renderer: EffectRenderer
    private lateinit var editor: EditText
    private lateinit var errorConsole: TextView
    private lateinit var applyBtn: Button
    private lateinit var templateBtn: Button
    private lateinit var errorBar: View

    private val debounceHandler = Handler(Looper.getMainLooper())
    private val debounceDelay = 800L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_custom_shader)

        glSurface = findViewById(R.id.customGlSurface)
        editor = findViewById(R.id.shaderEditor)
        errorConsole = findViewById(R.id.errorConsole)
        applyBtn = findViewById(R.id.applyShaderBtn)
        templateBtn = findViewById(R.id.templateBtn)
        errorBar = findViewById(R.id.errorBar)

        renderer = EffectRenderer()
        glSurface.setEGLContextClientVersion(3)
        glSurface.setRenderer(renderer)
        glSurface.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY

        editor.setText(ShaderBuilder.CUSTOM_SHADER_TEMPLATE)

        editor.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                debounceHandler.removeCallbacksAndMessages(null)
                debounceHandler.postDelayed({ applyShader() }, debounceDelay)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        applyBtn.setOnClickListener { applyShader() }

        templateBtn.setOnClickListener {
            editor.setText(ShaderBuilder.CUSTOM_SHADER_TEMPLATE)
        }

        supportActionBar?.apply {
            title = "Custom GLSL"
            setDisplayHomeAsUpEnabled(true)
        }
    }

    private fun applyShader() {
        val src = editor.text.toString()
        glSurface.queueEvent {
            renderer.setCustomShader(src)
        }
        // Check for errors after a short delay
        Handler(Looper.getMainLooper()).postDelayed({
            val err = renderer.lastShaderError
            if (err != null) {
                errorBar.visibility = View.VISIBLE
                errorConsole.text = parseError(err)
                renderer.lastShaderError = null
            } else {
                errorBar.visibility = View.GONE
                errorConsole.text = ""
            }
        }, 200)
    }

    private fun parseError(raw: String): String {
        // Format GLSL error: "0:42: error: ..." → "Line 42: ..."
        return raw.lines().take(3).joinToString("\n") { line ->
            val m = Regex("""(\d+):(\d+):\s*(.+)""").find(line)
            if (m != null) "Line ${m.groupValues[2]}: ${m.groupValues[3]}"
            else line
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
    override fun onResume() { super.onResume(); glSurface.onResume() }
    override fun onPause() { super.onPause(); glSurface.onPause() }
}
