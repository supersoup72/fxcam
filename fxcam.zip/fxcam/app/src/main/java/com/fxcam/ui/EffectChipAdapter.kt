package com.fxcam.ui

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.fxcam.R
import com.fxcam.effects.Effect
import java.util.Collections

class EffectChipAdapter(
    private val items: MutableList<Effect>,
    private val onToggle: (Effect) -> Unit,
    private val onSelect: (Effect) -> Unit,
    private val dragHelper: () -> ItemTouchHelper?
) : RecyclerView.Adapter<EffectChipAdapter.VH>() {

    var selectedId: String? = null

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val label: TextView = v.findViewById(R.id.chipLabel)
        val check: TextView = v.findViewById(R.id.chipCheck)
        val drag: View = v.findViewById(R.id.chipDrag)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_effect_chip, parent, false))

    @SuppressLint("ClickableViewAccessibility")
    override fun onBindViewHolder(h: VH, position: Int) {
        val effect = items[position]
        h.label.text = effect.name
        h.check.visibility = if (effect.enabled) View.VISIBLE else View.INVISIBLE

        val selected = effect.id == selectedId
        val bg = if (selected) R.drawable.chip_selected else R.drawable.chip_normal
        h.itemView.setBackgroundResource(bg)

        h.itemView.setOnClickListener {
            selectedId = effect.id
            onSelect(effect)
            notifyDataSetChanged()
        }

        h.itemView.setOnLongClickListener {
            effect.enabled = !effect.enabled
            onToggle(effect)
            notifyItemChanged(position)
            true
        }

        h.check.setOnClickListener {
            effect.enabled = !effect.enabled
            onToggle(effect)
            notifyItemChanged(position)
        }

        h.drag.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                dragHelper()?.startDrag(h)
            }
            false
        }
    }

    override fun getItemCount() = items.size

    fun move(from: Int, to: Int) {
        Collections.swap(items, from, to)
        notifyItemMoved(from, to)
    }

    fun getItems() = items
}

class EffectDragCallback(private val adapter: EffectChipAdapter) :
    ItemTouchHelper.SimpleCallback(ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0) {

    override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
        adapter.move(vh.adapterPosition, target.adapterPosition)
        return true
    }

    override fun onSwiped(vh: RecyclerView.ViewHolder, dir: Int) {}
    override fun isLongPressDragEnabled() = false
}
