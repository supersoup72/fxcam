package com.fxcam.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.fxcam.R
import com.fxcam.effects.EffectParam

class ParamSliderAdapter(
    private val params: MutableList<EffectParam>,
    private val onChange: () -> Unit
) : RecyclerView.Adapter<ParamSliderAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val label: TextView = v.findViewById(R.id.paramLabel)
        val value: TextView = v.findViewById(R.id.paramValue)
        val seek: SeekBar = v.findViewById(R.id.paramSeek)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_param_slider, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = params[position]
        h.label.text = p.label
        h.seek.max = 1000
        h.seek.progress = ((p.value - p.min) / (p.max - p.min) * 1000f).toInt().coerceIn(0, 1000)
        h.value.text = "%.2f".format(p.value)

        h.seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                p.value = p.min + (p.max - p.min) * (progress / 1000f)
                h.value.text = "%.2f".format(p.value)
                onChange()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    override fun getItemCount() = params.size

    fun updateParams(newParams: List<EffectParam>) {
        params.clear()
        params.addAll(newParams)
        notifyDataSetChanged()
    }
}
