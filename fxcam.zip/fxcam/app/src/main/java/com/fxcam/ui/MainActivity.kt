package com.fxcam.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fxcam.R
import com.fxcam.effects.Effect
import com.fxcam.effects.EffectRegistry
import com.fxcam.vulkan.EffectRenderer

class MainActivity : AppCompatActivity() {

    private lateinit var glSurface: GLSurfaceView
    private lateinit var renderer: EffectRenderer
    private lateinit var chipRecycler: RecyclerView
    private lateinit var paramRecycler: RecyclerView
    private lateinit var chipAdapter: EffectChipAdapter
    private lateinit var paramAdapter: ParamSliderAdapter
    private lateinit var modeTabGroup: RadioGroup
    private lateinit var renderBtn: Button
    private lateinit var loadMediaBtn: ImageButton
    private lateinit var settingsBtn: ImageButton
    private lateinit var noEffectHint: TextView
    private lateinit var dragHelper: ItemTouchHelper

    private val effects = EffectRegistry.defaultEffects()
    private var selectedEffect: Effect? = null
    private var currentMode = Mode.PHOTO

    enum class Mode { PHOTO, VIDEO, LIVE }

    private val pickMedia = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { loadImageFromUri(it) }
    }

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startLivePreview() else Toast.makeText(this, "Camera permission needed", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        glSurface = findViewById(R.id.glSurface)
        chipRecycler = findViewById(R.id.chipRecycler)
        paramRecycler = findViewById(R.id.paramRecycler)
        modeTabGroup = findViewById(R.id.modeTabGroup)
        renderBtn = findViewById(R.id.renderBtn)
        loadMediaBtn = findViewById(R.id.loadMediaBtn)
        settingsBtn = findViewById(R.id.settingsBtn)
        noEffectHint = findViewById(R.id.noEffectHint)

        setupGLSurface()
        setupChipRecycler()
        setupParamRecycler()
        setupModeTabs()
        setupButtons()
    }

    private fun setupGLSurface() {
        renderer = EffectRenderer()
        glSurface.setEGLContextClientVersion(3)
        glSurface.setRenderer(renderer)
        glSurface.renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
    }

    private fun setupChipRecycler() {
        var touchHelper: ItemTouchHelper? = null
        chipAdapter = EffectChipAdapter(
            items = effects,
            onToggle = { onEffectToggled() },
            onSelect = { effect -> onEffectSelected(effect) },
            dragHelper = { touchHelper }
        )
        val dragCallback = EffectDragCallback(chipAdapter)
        touchHelper = ItemTouchHelper(dragCallback)
        dragHelper = touchHelper

        chipRecycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        chipRecycler.adapter = chipAdapter
        touchHelper.attachToRecyclerView(chipRecycler)
    }

    private fun setupParamRecycler() {
        paramAdapter = ParamSliderAdapter(mutableListOf()) { onParamsChanged() }
        paramRecycler.layoutManager = LinearLayoutManager(this)
        paramRecycler.adapter = paramAdapter
    }

    private fun onEffectToggled() {
        renderer.effects = effects.filter { it.enabled }
        glSurface.requestRender()
        updateParamPanel()
    }

    private fun onEffectSelected(effect: Effect) {
        selectedEffect = effect
        if (effect.id == "custom") {
            startActivity(Intent(this, CustomShaderActivity::class.java))
            return
        }
        updateParamPanel()
    }

    private fun updateParamPanel() {
        val ef = selectedEffect
        if (ef == null || ef.params.isEmpty()) {
            noEffectHint.visibility = View.VISIBLE
            paramRecycler.visibility = View.GONE
        } else {
            noEffectHint.visibility = View.GONE
            paramRecycler.visibility = View.VISIBLE
            paramAdapter.updateParams(ef.params)
        }
    }

    private fun onParamsChanged() {
        renderer.effects = effects.filter { it.enabled }
        glSurface.requestRender()
    }

    private fun setupModeTabs() {
        modeTabGroup.setOnCheckedChangeListener { _, id ->
            currentMode = when (id) {
                R.id.tabPhoto -> Mode.PHOTO
                R.id.tabVideo -> Mode.VIDEO
                R.id.tabLive  -> Mode.LIVE
                else -> Mode.PHOTO
            }
            updateRenderButton()
            if (currentMode == Mode.LIVE) {
                checkCameraAndStart()
            }
        }
    }

    private fun updateRenderButton() {
        renderBtn.text = when (currentMode) {
            Mode.PHOTO -> "📷  CAPTURE"
            Mode.VIDEO -> "🎬  EXPORT VIDEO"
            Mode.LIVE  -> "⬤  RENDER FRAME"
        }
    }

    private fun setupButtons() {
        loadMediaBtn.setOnClickListener {
            pickMedia.launch("image/*")
        }
        settingsBtn.setOnClickListener {
            Toast.makeText(this, "Settings coming soon", Toast.LENGTH_SHORT).show()
        }
        renderBtn.setOnClickListener {
            when (currentMode) {
                Mode.PHOTO -> capturePhoto()
                Mode.VIDEO -> Toast.makeText(this, "Video export: pick a video first", Toast.LENGTH_SHORT).show()
                Mode.LIVE  -> capturePhoto()
            }
        }
        updateRenderButton()
    }

    private fun loadImageFromUri(uri: Uri) {
        try {
            val bmp = MediaStore.Images.Media.getBitmap(contentResolver, uri)
            val scaled = Bitmap.createScaledBitmap(bmp, 1080, (1080f / bmp.width * bmp.height).toInt(), true)
            glSurface.queueEvent { renderer.loadBitmap(scaled) }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not load image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkCameraAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            startLivePreview()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startLivePreview() {
        Toast.makeText(this, "Live preview: attach CameraX to GLSurface", Toast.LENGTH_SHORT).show()
        // CameraX live feed integration point
    }

    private fun capturePhoto() {
        Toast.makeText(this, "Saving...", Toast.LENGTH_SHORT).show()
        // Read pixels from GLSurface, save to gallery
    }

    override fun onResume() {
        super.onResume()
        glSurface.onResume()
    }

    override fun onPause() {
        super.onPause()
        glSurface.onPause()
    }
}
