package com.fxcam.effects

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

enum class EffectCategory { WARP, LIGHTING, POST, CUSTOM }

@Parcelize
data class EffectParam(
    val key: String,
    val label: String,
    val min: Float,
    val max: Float,
    val default: Float,
    var value: Float = default
) : Parcelable

@Parcelize
data class Effect(
    val id: String,
    val name: String,
    val category: EffectCategory,
    val params: List<EffectParam>,
    var enabled: Boolean = false,
    var order: Int = 0
) : Parcelable

object EffectRegistry {

    fun defaultEffects(): MutableList<Effect> = mutableListOf(
        Effect("hue_shift", "Hue Shift", EffectCategory.POST, listOf(
            EffectParam("shift", "Shift", 0f, 360f, 0f),
            EffectParam("saturation", "Saturation", 0f, 2f, 1f)
        )),
        Effect("v_wiggle", "V-Wiggle", EffectCategory.WARP, listOf(
            EffectParam("se", "Speed", 0f, 10f, 2f),
            EffectParam("radius", "Amplitude", 0f, 10f, 3f),
            EffectParam("skew", "Skew", 0f, 5f, 1f)
        )),
        Effect("h_wiggle", "H-Wiggle", EffectCategory.WARP, listOf(
            EffectParam("se", "Speed", 0f, 10f, 2f),
            EffectParam("radius", "Amplitude", 0f, 10f, 3f),
            EffectParam("skew", "Skew", 0f, 5f, 1f)
        )),
        Effect("vwave", "V-Wave", EffectCategory.WARP, listOf(
            EffectParam("se", "Amplitude", 0f, 20f, 5f),
            EffectParam("stretch", "Frequency", 1f, 30f, 10f),
            EffectParam("speed", "Speed", 0f, 5f, 1f)
        )),
        Effect("hwave", "H-Wave", EffectCategory.WARP, listOf(
            EffectParam("se", "Amplitude", 0f, 20f, 5f),
            EffectParam("stretch", "Frequency", 1f, 30f, 10f),
            EffectParam("speed", "Speed", 0f, 5f, 1f)
        )),
        Effect("swirl", "Swirl", EffectCategory.WARP, listOf(
            EffectParam("se", "Rotation", 0f, 180f, 45f),
            EffectParam("radius", "Radius", 0f, 20f, 5f),
            EffectParam("posx", "Center X", 0f, 1f, 0.5f),
            EffectParam("posy", "Center Y", 0f, 1f, 0.5f)
        )),
        Effect("fish", "Fisheye", EffectCategory.WARP, listOf(
            EffectParam("se", "Strength", 0f, 5f, 1f),
            EffectParam("radius", "Radius", 0f, 20f, 5f),
            EffectParam("posx", "Center X", 0f, 1f, 0.5f),
            EffectParam("posy", "Center Y", 0f, 1f, 0.5f)
        )),
        Effect("ripple", "Ripple", EffectCategory.WARP, listOf(
            EffectParam("se", "Frequency", 0f, 50f, 20f),
            EffectParam("radius", "Amplitude", 0f, 10f, 3f),
            EffectParam("speed", "Speed", 0f, 5f, 1f),
            EffectParam("posx", "Center X", 0f, 1f, 0.5f),
            EffectParam("posy", "Center Y", 0f, 1f, 0.5f)
        )),
        Effect("fractal", "Fractal", EffectCategory.WARP, listOf(
            EffectParam("se", "Scale", 0f, 5f, 1f),
            EffectParam("radius", "Influence", 0f, 20f, 5f),
            EffectParam("speed", "Speed", 0f, 5f, 1f),
            EffectParam("posx", "Center X", 0f, 1f, 0.5f),
            EffectParam("posy", "Center Y", 0f, 1f, 0.5f)
        )),
        Effect("rays", "God Rays", EffectCategory.LIGHTING, listOf(
            EffectParam("length", "Length", 0f, 1f, 0.1f),
            EffectParam("threshold", "Threshold", 0f, 1f, 0.45f),
            EffectParam("strength", "Strength", 0f, 5f, 2f)
        )),
        Effect("glow", "Glow", EffectCategory.LIGHTING, listOf(
            EffectParam("percentage", "Radius", 0f, 10f, 2f),
            EffectParam("intensity", "Intensity", 0f, 5f, 2f),
            EffectParam("suppression", "Cutoff", 0f, 1f, 0.45f)
        )),
        Effect("nb_wiggle", "Organic Wiggle", EffectCategory.POST, listOf(
            EffectParam("se", "Wave Freq", 0f, 20f, 5f),
            EffectParam("rate", "Rate", 0f, 20f, 10f),
            EffectParam("strength", "Strength", 0f, 10f, 2f),
            EffectParam("drift", "Drift", 0f, 10f, 5f),
            EffectParam("crop", "Crop", 0f, 10f, 0f)
        )),
        Effect("crt_beam", "CRT Beam", EffectCategory.POST, listOf(
            EffectParam("speed", "Speed", 0f, 5f, 1.5f),
            EffectParam("strength", "Brightness", 0f, 1f, 0.45f),
            EffectParam("radius", "Width", 0f, 0.005f, 0.0008f)
        )),
        Effect("custom", "Custom GLSL", EffectCategory.CUSTOM, emptyList())
    )
}
