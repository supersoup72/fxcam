package com.fxcam.vulkan

import android.graphics.Bitmap
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import com.fxcam.effects.Effect
import com.fxcam.effects.ShaderBuilder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class EffectRenderer : GLSurfaceView.Renderer {

    private var program = 0
    private var texture = 0
    private val textures = IntArray(1)
    private var width = 1; private var height = 1
    private var time = 0f
    private var aspect = 1f
    private var dirty = true
    private var pendingBitmap: Bitmap? = null
    private var pendingShader: String? = null

    var effects: List<Effect> = emptyList()
        set(value) { field = value; dirty = true }

    private val quadVerts = floatArrayOf(
        -1f, -1f, 0f, 0f,
         1f, -1f, 1f, 0f,
        -1f,  1f, 0f, 1f,
         1f,  1f, 1f, 1f
    )
    private lateinit var vb: FloatBuffer

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0f, 0f, 0f, 1f)
        vb = ByteBuffer.allocateDirect(quadVerts.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer()
            .apply { put(quadVerts); position(0) }
        GLES30.glGenTextures(1, textures, 0)
        texture = textures[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texture)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        rebuildProgram()
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = w; height = h
        GLES30.glViewport(0, 0, w, h)
        aspect = w.toFloat() / h.toFloat()
    }

    override fun onDrawFrame(gl: GL10?) {
        time += 0.016f

        pendingBitmap?.let { bmp ->
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texture)
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
            pendingBitmap = null
            dirty = true
        }

        if (dirty || pendingShader != null) {
            pendingShader?.let { src ->
                rebuildProgramWithSource(src)
                pendingShader = null
            }
            if (dirty) {
                rebuildProgram()
                dirty = false
            }
        }

        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        if (program == 0) return

        GLES30.glUseProgram(program)

        val aPos = GLES30.glGetAttribLocation(program, "aPosition")
        val aTex = GLES30.glGetAttribLocation(program, "aTexCoord")
        val uTex = GLES30.glGetUniformLocation(program, "uTexture")
        val uTime = GLES30.glGetUniformLocation(program, "uTime")
        val uAsp = GLES30.glGetUniformLocation(program, "uAspect")

        vb.position(0)
        GLES30.glVertexAttribPointer(aPos, 2, GLES30.GL_FLOAT, false, 16, vb)
        GLES30.glEnableVertexAttribArray(aPos)

        vb.position(2)
        GLES30.glVertexAttribPointer(aTex, 2, GLES30.GL_FLOAT, false, 16, vb)
        GLES30.glEnableVertexAttribArray(aTex)

        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, texture)
        GLES30.glUniform1i(uTex, 0)
        GLES30.glUniform1f(uTime, time)
        GLES30.glUniform1f(uAsp, aspect)

        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun loadBitmap(bmp: Bitmap) { pendingBitmap = bmp }
    fun markDirty() { dirty = true }
    fun setCustomShader(src: String) { pendingShader = src }

    private fun rebuildProgram() {
        val frag = ShaderBuilder.buildFragmentShader(effects, time, aspect)
        rebuildProgramWithSource(frag)
    }

    private fun rebuildProgramWithSource(fragSrc: String) {
        if (program != 0) GLES30.glDeleteProgram(program)
        val vert = compileShader(GLES30.GL_VERTEX_SHADER, ShaderBuilder.VERTEX_SHADER)
        val frag = compileShader(GLES30.GL_FRAGMENT_SHADER, fragSrc)
        if (vert == 0 || frag == 0) { program = 0; return }
        program = GLES30.glCreateProgram().also {
            GLES30.glAttachShader(it, vert)
            GLES30.glAttachShader(it, frag)
            GLES30.glLinkProgram(it)
            GLES30.glDeleteShader(vert)
            GLES30.glDeleteShader(frag)
        }
    }

    private fun compileShader(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val status = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, status, 0)
        return if (status[0] == GLES30.GL_TRUE) s else {
            val log = GLES30.glGetShaderInfoLog(s)
            android.util.Log.e("FXCam", "Shader error: $log")
            lastShaderError = log
            GLES30.glDeleteShader(s)
            0
        }
    }

    var lastShaderError: String? = null
}
